"use strict";
var name = "TypeScript";
var greeting = "Hello, " + name + "! Your name has " + name.length + " characters";
