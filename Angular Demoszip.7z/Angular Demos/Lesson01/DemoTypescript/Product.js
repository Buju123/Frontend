"use strict";
var All;
(function (All) {
    var IProduct = /** @class */ (function () {
        function IProduct() {
        }
        return IProduct;
    }());
    All.IProduct = IProduct;
})(All || (All = {}));
