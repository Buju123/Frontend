"use strict";
var log = function (message) {
    console.log('Welcome to Arrow');
};
//Arrow function equivalent to above function 
var doLog = function (message) { return console.log(message); };
//Arrow function equivalent to no parameter  function 
var withoutparameter = function () { return console.log(); };
