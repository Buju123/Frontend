"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IProduct = /** @class */ (function () {
    function IProduct() {
    }
    return IProduct;
}());
exports.IProduct = IProduct;
exports.company = "capgemini";
