var sname = "TypeScript";
var greeting  = `Hello, ${sname}! Your name 


has ${sname.length} characters`;
console.log(greeting);