export interface Order {
    buyQty?;
    buyPrice?;
    sellQty?;
    sellPrice?;
}
